#ifndef __ERR_H__
#define __ERR_H__



typedef enum {START=0, OK=0, OVERFLOW, ALLOC_FAILED, UNDERFLOW, INDEX_ERROR, EMPTY_OR_ONE, INPUT_ERR, WRONG_API, END} ADTERR;




#endif /* #ifndef __ERR_H__ */
