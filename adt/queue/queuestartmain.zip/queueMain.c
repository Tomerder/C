#include<stdio.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>
#include "queue.h"
#include "err.h"


#define SIZE 10
#define PRINT_ERR if(err!=0) printf("error no. %d\n",err)

void printFuncInt(Item _item);
void insertTest();


/*------------------------------------------------------------------------------------*/

int main(int argc,char** argv)
{
	
	insertTest();


    return 0; 	
}

/*------------------------------------------------------------------------------------*/	
	
void insertTest(){
	Queue* queue; 
	PrintFunc printfunc = printFuncInt;
	int err , toInsert = 5;

	queue = QueueCreate(SIZE);   /*setup*/

	err=QueueInsert(queue, &toInsert);  
	PRINT_ERR;

	QueuePrint(queue,printfunc);

	QueueDestroy(queue);    /*cleanup*/

	/*return OK;*/
}

/*------------------------------------------------------------------------------------*/


void printFuncInt(Item _item){
	printf("%d" , *((int*)(_item))  );


}


