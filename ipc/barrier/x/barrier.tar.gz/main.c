/*****************************************************************************************************************
*    AUTHOR: 		Tomer Dery                                                                                 
*    DATE: 			16.02.14                                                                                              
*    LAST MODIFIED: 16.02.14                                                                                  
*    DESCRIPTION: 	Barrier
*****************************************************************************************************************/
#ifndef _XOPEN_SOURCE 
#define _XOPEN_SOURCE 500
#endif
/*-----------------------------------------------------------------*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>
#include <semaphore.h>
#include <time.h>

/*-----------------------------------------------------------------*/

#include "barrier.h"

/*-----------------------------------------------------------------*/

enum{FALSE , TRUE};

#define MSG_SIZE 64

#define TXT_COUNT "thread %u => index %d => counting: %d => iter: %d\n"

#define DEFAULT_N_OF_THREADS 3
#define DEFAULT_N_OF_ITERS 1
#define DEFAULT_WORK_TIME 100000
#define MICROSEC_MUL_RES 1000
#define DEBUG FALSE

#define CHKERR(ERR , RET) if(ERR != OK_E) { printf("ERROR :%d\n", RET); return RET; }

#define DEBUG FALSE

#define PRINT_U_D(MSG,U)  if(DEBUG) printf(MSG,U)

/*-----------------------------------------------------------------*/

typedef struct Args{
	int m_numOfThreads;
	int m_numOfIters;	
	int m_workTime;
	int m_isDebug;
}Args;

/*-----------------------------------------------------------------*/

void GetArgs(int argc ,char** argv);

int Init(Barrier** _bar, pthread_t** _countingThreads ,int** _countingArr);

int Work(Barrier* _bar, pthread_t* _countingThreads, pthread_t _sumThread ,int* _countingArr);

int FinishWork(Barrier* _bar, pthread_t* _countingThreads ,int* _countingArr);

void Clean(Barrier* _bar, pthread_t* _countingThreads, int* _countingArr);

void* CountThread(void* _parm);
void* SumThread(void* _parm);

/*-----------------------------------------------------------------*/

int ChkTotal(int _chkTotal);

/*-----------------------------------------------------------------*/

Args args = {DEFAULT_N_OF_THREADS, DEFAULT_N_OF_ITERS , DEFAULT_WORK_TIME , DEBUG} ;

/*-----------------------------------------------------------------*/

typedef struct CountThreadParams{
	Barrier* m_bar;
	int* m_countingArr;
	int m_threadIndex;
}CountThreadParams;

/*-----------------------------------------------------------------*/

int main(int argc,char** argv)
{	
    int err;
	pthread_t* countingThreads = NULL;
	pthread_t sumThread;
	Barrier* bar = NULL;
	int* countingArr = NULL;
	
	GetArgs(argc ,argv);
	
	/*init*/
	err = Init(&bar, &countingThreads, &countingArr);
	CHKERR(err, ERROR);
    
    /*start prods and cons*/
    err = Work(bar, countingThreads, sumThread, countingArr);
    CHKERR(err, ERROR);
    
    /*wait for threads to finish the job*/
    err = FinishWork(bar, countingThreads, countingArr);
    CHKERR(err, ERROR);
    
    /*clean*/
    Clean(bar, countingThreads, countingArr);
		
	printf("PROG ENDED\n");
	
	return OK_E;
}

/*-----------------------------------------------------------------*/

int Work(Barrier* _bar, pthread_t* _countingThreads, pthread_t _sumThread ,int* _countingArr)
{
	int i;
	CountThreadParams* params = malloc(args.m_numOfThreads * sizeof(CountThreadParams));
	
	/*start counting threads*/
	for(i=0; i < args.m_numOfThreads; i++){
		params[i].m_bar = _bar;
		params[i].m_countingArr = _countingArr;
		params[i].m_threadIndex = i;

		pthread_create(&_countingThreads[i], NULL, CountThread, (void*)(&params[i]));   
	}
	
	/*start sum thread*/
	/*pthread_create(&_sumThread, NULL, SumThread, (void*)(&_bar));*/ 

	return OK_E;
}

/*-----------------------------------------------------------------*/

void* CountThread(void* _parm)
{
	CountThreadParams* params = (CountThreadParams*)_parm; 
	Barrier* bar = params->m_bar;
	int* countingArr = params->m_countingArr;
	int threadIndex = params->m_threadIndex;  
	int iter,count;
	unsigned tid = pthread_self(); 
	
	printf("THREAD STARTED: %u => index: %d\n", tid, threadIndex);
	
	for(iter=0; iter < args.m_numOfIters; iter++){
		/*barrier*/
		BarrierWait(bar);
		
		PRINT_U_D("THREAD EXIT WAIT: %u\n", tid);
		
		/*counting loop*/
		for(count=0; count < threadIndex + 1 ;count++){
			printf(TXT_COUNT, tid, threadIndex, count, iter);
			
			countingArr[threadIndex]++;
			
			/*work*/
			usleep(args.m_workTime);
		}
		
		printf("END OF ITER %d => %u\n", iter, tid);
	}
	
	return (void*)OK_E;
}

/*-----------------------------------------------------------------*/

void* SumThread(void* _parm)
{
	Barrier* bar = (Barrier*)_parm;
	
	unsigned tid = pthread_self(); 
	
	printf("SUM THREAD STARTED: %u\n", tid);
	
	
	/*barrier*/
	BarrierWait(bar);
	
	return (void*)OK_E;
}



/*-----------------------------------------------------------------*/

int FinishWork(Barrier* _bar, pthread_t* _countingThreads ,int* _countingArr)
{
	int err;
	int i;
	
	printf("ENTERED FinishWork\n");
	
	/*join all threads*/
	for(i=0; i < args.m_numOfThreads; i++){
		err = pthread_join(_countingThreads[i], NULL);
		CHKERR(err, THREAD_JOIN_ERR);

		printf("THREAD %u JOINED\n", (unsigned)_countingThreads[i]);
	}

	printf("EXITED FinishWork\n");

	return OK_E;
}

/*-----------------------------------------------------------------*/

int Init(Barrier** _bar, pthread_t** _countingThreads ,int** _countingArr)
{
    /*create barrier*/
    *_bar = BarrierInit(args.m_numOfThreads); /*+ 1);*/
    if (*_bar == NULL){
		return ALOC_ERR;
	}           
	
    /*counting threads*/
	*_countingThreads = malloc( args.m_numOfThreads * sizeof(pthread_t) );
	if (*_countingThreads == NULL){
		return ALOC_ERR;
	}
	
	 /*counting arr*/
	*_countingArr = malloc( args.m_numOfThreads * sizeof(int) );
	if (*_countingArr == NULL){
		return ALOC_ERR;
	}
	
	return OK_E;
}

/*-----------------------------------------------------------------*/

void Clean(Barrier* _bar, pthread_t* _countingThreads, int* _countingArr)
{
	free(_countingThreads);
	free(_countingArr);

	BarrierDestroy(_bar);
}

/*-----------------------------------------------------------------*/

void GetArgs(int _argc ,char** _argv)
{
	int argType;

	/*set args from agrv*/	
	while ((argType = getopt(_argc, _argv, "n:i:s:d")) != -1)
	{
		switch(argType)
		{
			case 'n':
				args.m_numOfThreads = atoi(optarg);
				break;	
			case 'i':
				args.m_numOfIters = atoi(optarg);
				break;	
			case 's':
				args.m_workTime = atoi(optarg) * MICROSEC_MUL_RES;
				break;
			case 'd':
				args.m_isDebug = TRUE;
				break;	
			default:				
				break;
		}
	}	
}

/*-----------------------------------------------------------------*/
