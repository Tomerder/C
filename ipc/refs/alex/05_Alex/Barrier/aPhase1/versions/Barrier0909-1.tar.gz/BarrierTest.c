/***************************************************************************
    Author: Stav Ofer
    Creation date:  		2013-09-09    
    Last modified date:		2013-09-09
    Description: 	conditional variables
****************************************************************************/

#ifndef _XOPEN_SOURCE
#define _XOPEN_SOURCE
#endif

#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <pthread.h>
#include <assert.h>

#include "Barrier.h"

/*######################################################################*/

#define DEF_THRESH	5

void* FuncThread(void* _barrier);
void* LastThread(void* _barrier);

int g_sum;


/*######################################################################*/
/*									MAIN								*/
/*######################################################################*/
int main(int argc, char* argv[])
{
	Barrier* myBar;
	pthread_t lastFunc, *funcs;
	int N = (argc > 1) ? atoi(argv[1]) : DEF_THRESH;
	int i;
	
	/*** initialize ***/
	g_sum = 0;
	
	myBar = BarrierInit(N);
	if(!myBar)
	{
		perror("BarrierInit");
		return -1;
	}
	
	funcs = (pthread_t*)malloc( (N-1) * sizeof(pthread_t) );
	if(!funcs)
	{
		perror("malloc");
		return -1;
	}
	
	
	/* create N-1 regular threads */
	for(i=0; i<N-2; ++i)
	{
		pthread_create(&funcs[i], 0, FuncThread, (void*)myBar);
	}
	
/*	sleep(2);*/
	
	printf("main before: sum is %d\n", g_sum);
	
	/* create last thread */
	pthread_create(&lastFunc, 0, LastThread, (void*)myBar);
	
	printf("main after: sum is %d\n", g_sum);
	
	free(funcs);
	return 0;
}
/*######################################################################*/



/*######################################################################*/
void* FuncThread(void* _barrier)
{
	Barrier* bar = (Barrier*)_barrier;
	int current;
	
	current = ++bar->m_counter;
	printf("func #%d\n", bar->m_counter);
	
	
	BarrierWait(bar);
	
	g_sum += current;
	
	pthread_exit(0);	/*** temp ***/
}
/*######################################################################*/


/*######################################################################*/
void* LastThread(void* _barrier)
{
	Barrier* bar = (Barrier*)_barrier;
	int current;
	
	current = ++bar->m_counter;
	
	printf("counter: %d\n", bar->m_counter);
	printf("sum: %d\n", g_sum);
	
	BarrierWait(bar);
	
	g_sum += current;
	printf(" new sum: %d\n", g_sum);
	
	pthread_exit(0);
}
/*######################################################################*/


