/**************************************************************************************
    Author: Stav Ofer
    Creation date:  		2013-09-15    
    Last modified date:		2013-09-15
    Description: producer-consumer - consumer module
***************************************************************************************/

#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include <pthread.h>

#include "GenericQueue.h"
#include "Consumer.h"


/*######################################################################*/
/*							DEFINITIONS									*/
/*######################################################################*/

#define QUEUE		(_consumer->m_queue)
#define COUNTER		(_consumer->m_counter)
#define	Q_NITEMS	(QueueCountItems(QUEUE))
#define CAPACITY	(_consumer->m_qCapacity)
#define LOCK		(_consumer->m_lock)
#define COND		(_consumer->m_cond)


struct Consumer_t
{
	Queue			*m_queue;
	pthread_mutex_t	*m_lock;
	pthread_cond_t	*m_cond;
	int				 m_qCapacity;
	int				 m_counter; /* # of consumed items */
	int				 m_done;
};



/*######################################################################*/
/*							API FUNCTIONS								*/
/*######################################################################*/


/*######################################################################*/
/* initialize consumer thread, return null for failure */
Consumer*	ConsumerInit	(Queue* _queue, pthread_mutex_t* _lock, pthread_cond_t *_cond, size_t _queueCapacity)
{
	Consumer *consumer = NULL;
	
	assert(_queue && _lock && _cond);
	
	consumer = (Consumer*)malloc(sizeof(Consumer));
	if(!consumer) {
		return NULL;
	}
	
	consumer->m_queue		= _queue;
	consumer->m_lock		= _lock;
	consumer->m_cond		= _cond;
	consumer->m_qCapacity	= _queueCapacity;
	consumer->m_counter 	= 0;
	consumer->m_done		= 0;
	
	return consumer;
}
/*######################################################################*/


/*######################################################################*/
/* free everything */
void		ConsumerDestroy	(Consumer *_consumer)
{
	assert(_consumer);
	
	pthread_mutex_destroy(LOCK);
	pthread_cond_destroy(COND);
	
	QueueDestroy(QUEUE);
	free(_consumer);
}
/*######################################################################*/


/*######################################################################*/
/* take item from queue */
void*		Consume			(Consumer *_consumer)
{
/*	int error;*/
	void* item;
	
	assert(_consumer);

	if(Q_NITEMS == 0)
	{	/* if queue empty - wait */
		pthread_cond_wait(COND, LOCK);
	}
	else	/* take item - protected */
	{
		pthread_mutex_lock(LOCK);	/* lock */
		
		++COUNTER;
		item = QueueRemove(QUEUE);
		
		if(Q_NITEMS == CAPACITY-1)
		{	/* if queue was full - wakup producers */
			pthread_cond_broadcast(COND);
		}
		
		pthread_mutex_unlock(LOCK);	/* unlock */
	}
	return item;
}
/*######################################################################*/


/*######################################################################*/
/* exit when done: raise flag & wake all sleepers */
void		ConsumerDone	(Consumer *_consumer)
{
	assert(_consumer);
	_consumer->m_done = 1;
	
	pthread_cond_broadcast(COND);
}
/*######################################################################*/


/*######################################################################*/
/* return 1 if done, 0 if not */
int			ConsumerIsDone	(Consumer *_consumer)
{
	return _consumer->m_done;
}
/*######################################################################*/


/*######################################################################*/
/* get # of items consumed */
int			ConsumerGetTotal (Consumer *_consumer)
{
	return COUNTER;
}
/*######################################################################*/




