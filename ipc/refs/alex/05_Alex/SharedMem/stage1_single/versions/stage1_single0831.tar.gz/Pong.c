/***************************************************************************
    Author: Stav Ofer
    Creation date:  		2013-08-31    
    Last modified date:		2013-08-31
    Description: 	ping pong with shared memory - passing messages one at a time.
    				stage 1 - single ping & single pong, single message
    				controlled by semaphore: each player locks itself & frees
    				the other.
    				
****************************************************************************/

#ifndef _XOPEN_SOURCE
#define _XOPEN_SOURCE 500
#endif

#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include <sys/shm.h>

#include "PingPong.h"


/*######################################################################*/
/*				definitions & foreward declarations						*/
/*######################################################################*/

#define NSEMS			2
#define SIZE			getpagesize()
#define SEMFLAGS		0
#define SHMFLAGS		0
#define SEMOP_PING_FLG	0
#define SEMOP_PONG_FLG	0


/*######################################################################*/
/*									MAIN								*/
/*######################################################################*/
int main(int argc, char *argv[])
{
	Options options;				/* runtime options	*/
	SendRecvArg sendArgs; 			/* arguments for send	*/
	SendRecvArg recvArgs;			/* arguments for receive */
	char inboxBuffer[MAX_MSG_LEN];	/* buffer for incoming message */
	
	struct sembuf sopsPing, sopsPong;	/* semaphore operations args */
	
	char* myShm;			/* ptr to start of shared memory */
	
	int semid, shmid;		/* semaphore & sharedMem id	*/
	int pid = getpid();		/* process id */
	
int i;
char* temp;

	/* initialize & handle runtime options */
	OptHandler(argc, argv, &options);
	
	/* create/connect to semaphore */
	if( -1 == (semid = SemConnect(NSEMS, SEMFLAGS)) )
	{
		fprintf(stderr, "%s:%d Error: SemConnect\n", __FILE__, __LINE__-2);
		return errno;
	}
	
	/* create/connect to shared memory */
	if( -1 == (shmid = ShmConnect(SIZE, SEMFLAGS)) )
	{
		fprintf(stderr, "%s:%d Error: ShmConnect\n", __FILE__, __LINE__-2);
		return errno;
	}
	
	/* attach */
	if( (char *)(-1) == (myShm = shmat(shmid, (void *)0, 0)) )
	{
		perror("shmat");
		return errno;
	}
	
	/* initialize semaphore operation structures: up for ping and down for pong */
	sopsPing.sem_num = PING;
	sopsPing.sem_op  = UP;
	sopsPing.sem_flg = SEMOP_PING_FLG;
	
	sopsPong.sem_num = PONG;
	sopsPong.sem_op  = DOWN;
	sopsPong.sem_flg = SEMOP_PONG_FLG;
	
	/* initialize msg send, receive arguments */
	sendArgs.m_counter 	= 0;
	sendArgs.m_from 	= PONG;
	sendArgs.m_pid		= pid;
	sendArgs.m_shm 		= myShm;
	
	recvArgs.m_counter 	= 0;
	recvArgs.m_from 	= PING;
	recvArgs.m_pid		= pid;
	recvArgs.m_shm 		= myShm;
	
	
	/*** message receive & reply loop ***/
printf("shmid: %d\n", shmid);
printf("myShm: %p\n", myShm);
printf("counter: %d\n", COUNTER(myShm));

for(i=-4, temp = myShm-4; i<8; ++i, ++temp)
{
	printf("%d: %d\n", i, *temp);
}


	while( COUNTER(myShm) > 0 )
	{
		/* pong semaphore down - wait for ping to unlock it */
		if( -1 == semop(semid, &sopsPong, 1) )
		{
			perror("semop");
			return errno;
		}
		SemValuePrint(semid, &options);
		
		/* read message */
		printf("Pong %d: ", pid);
		MsgRecv(&recvArgs, inboxBuffer);
		
		/* send reply */
		printf("Pong %d: ", pid);
		MsgSend(&sendArgs);
		
		/* unlock ping */
		if( -1 == semop(semid, &sopsPing, 1) )
		{
			perror("semop");
			return errno;
		}
		SemValuePrint(semid, &options);
		
		/* sleep */
		usleep(options.m_usleep);
	}
	/* end receive-reply loop */
	
	PrintV(&options, "Pong: ", pid);
	PrintV(&options, "# of messeges received:", recvArgs.m_counter);
	PrintV(&options, "# of messeges sent:", sendArgs.m_counter);
	
	/* detach */
	if( -1 == shmdt(myShm) )
	{
		perror("shmdt");
		return -1;
	}
	
	return errno;	
}
/*######################################################################*/


