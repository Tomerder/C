/**************************************************************************************
    Author: Stav Ofer
    Creation date:  		2013-08-08    
    Last modified date:		2013-08-10
    Description: 	Memory management functions, in method of contiguous allocation.
    				Overhead:	metadata of each block - additional 4 bytes per block,
    							also general metadata in struct MPool.
    				"Weak" prevention of fragmentation: joining 2 adjacent free blocks into one.
    				Size of chunk must be at least sizeof(MPool) + 8
***************************************************************************************/

#include <stdio.h>
#include <string.h>
#include <assert.h>

#include "MPoolNew.h"


/*######################################################################*/
/*				Definitions & Foreward declarations					*/
/*######################################################################*/

#define BOUND_SIZE		sizeof(void*)	/* size of boundary - 4 byte on 32-bit machines */

typedef unsigned int ui;

/* meta data for memory chunk */
struct MPool
{
	int		m_size;	/* size of memory chunck */
};

/* check if _mem is at a boundary, return ptr to next one */
static void* BoundaryCheck(void* _mem);

/* merge 2 adjoining memory chunks */
static void MergeMem(void* _mem1, void* _mem2);


/*######################################################################*/
/*								MPOOLINIT								*/
/*######################################################################*/


/*	Initialize memory chunck for use.
	Input:	_mem - handle to memory chunck
			_size - size in bytes
	Output: handle to MPool - beginning of memory chunk
*/
MPool* 	MPoolInit	(void *_mem, int _size)
{
	MPool pool;
	void *newMem = NULL;
	
	/* debug error checks */
	assert(_mem);
	assert(_size >= sizeof(MPool) + 8);
	
	/* set all bytes to 0 */
	memset(_mem, 0, _size);
	
	/* get closest following boundary */
	newMem = BoundaryCheck(_mem);

	/* decrease size accordingly */
	if(newMem != _mem)
	{
		_size -= (ui)newMem-(ui)_mem;
	}

	/* write actual free size to metadata - subtract size of mPool struct and of one block-metadata */
	pool.m_size = _size - sizeof(MPool) - BOUND_SIZE;
	
	/* put mPool at beginning of memory chunk */
	*(MPool*)newMem = pool;
	/* put size at beginning of block */
	*(int*)((ui)newMem + sizeof(MPool)) = pool.m_size;
	
	/* return address of mPool */
	return newMem;
}
/*----------------------------------------------------------------------*/


/*	Assign a block of memory to user
	Input:	_mPool
			_size - # of bytes to allocate
	Output:	handle to assigned memory block
			if not enough memory - return NULL
			same if size=0
*/
/*void* 	MPoolAlloc	(MPool* _mPool, int _size)*/
/*{*/

/*}*/


/*  given pointer to allocated data block _mem, set *_length to actual length of data
	and _actLocation to actual start of data, so that user can read data
	Input:	_mPool
			_mem - handle to assigned memory
			_length - is set to actual size in bytes of data
			_actLocation - is set to handle to actual start of message
*/
void	MPoolRead(MPool* _mPool, void* _mem, size_t* _length, void** _actLocation)
{

}


/*	Free memory block
	Input:	_mPool
			_memFree - handle to block
	Output: none
	if block does not belong to MPool, nothing happens
*/
/*void	MPoolFree	(MPool* _mPool, void* _memFree)*/
/*{*/

/*}*/



