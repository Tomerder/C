/**************************************************************************************
    Author: Stav Ofer
    Creation date:  		2013-08-08    
    Last modified date:		2013-09-16
    Description: 	Memory management functions, in method of contiguous allocation.
    				Overhead:	- metadata of each block - additional 4 bytes per block,
    							- padding to work in 4-byte units
    							- general metadata in struct MPool.
    				"Weak" prevention of fragmentation: joining 2 adjacent free blocks into one.
    				Size of chunk must be at least sizeof(MPool) + 8
    				
    				update 16/9: modified for use in message queue
***************************************************************************************/

#ifndef __MPOOL_NEW_H__
#define __MPOOL_NEW_H__

/* metadata for internal use */
typedef struct MPool MPool;


/*	Initialize memory chunck for use.
	Input:	_mem - handle to memory chunck
			_size - size in bytes
	Output: handle to MPool - beginning of memory chunk
*/
MPool* 	MPoolInit	(void *_mem, int _size);


/*	Assign a block of memory to user
	Input:	_mPool
			_size - # of bytes to allocate
	Output:	handle to assigned memory block
			if not enough memory - return NULL
			same if size=0
*/
//void* 	MPoolAlloc	(MPool* _mPool, int _size);


/*  given pointer to allocated data block _mem, set *_length to actual length of data
	and _actLocation to actual start of data, so that user can read data
	Input:	_mPool
			_mem - handle to assigned memory
			_length - is set to actual size in bytes of data
			_actLocation - is set to handle to actual start of message
*/
void	MPoolRead(MPool* _mPool, void* _mem, size_t* _length, void** _actLocation);


/*	Free memory block
	Input:	_mPool
			_memFree - handle to block
	Output: none
	if block does not belong to MPool, nothing happens
*/
//void	MPoolFree	(MPool* _mPool, void* _memFree);

#endif /* __MPOOL_NEW_H__ */

