/**************************************************************************************
    Author: Stav Ofer
    Creation date:  		2013-08-08    
    Last modified date:		2013-09-16
    Description: 	Memory management functions, in method of contiguous allocation.
     				Overhead:	metadata of each block, general metadata at start and 
     							end of memory chunk.
     				
     				Requries externally assigned memory chunk, with size of at least 
     				sizeof(MPool) + 4*block_metadata (usually 4 bytes)
     				
    				"Weak" defragmentation: when accessing a free block (in MPOOLALLOC or -FREE),
    				if following blocks are free - merging is performed.
    				
    				update 16/9: modified for use in message queue: added MPoolRead
    				& modified other functions to accomodate
***************************************************************************************/

#ifndef __MPOOL_NEW_H__
#define __MPOOL_NEW_H__

/* metadata for internal use, located at beginning of memory chunk */
typedef struct MPool MPool;


/*	Initialize memory chunck for use.
	Input:	_mem - handle to memory chunck
			_size - size in bytes
	Output: handle to MPool - beginning of memory chunk
*/
MPool* 	MPoolInit	(void *_mem, int _size);


/*	Allocate a block of memory to user
	Input:	_mPool
			_size - # of bytes to allocate
	Output:	handle to allocated memory block
			if not enough memory - return NULL
			same if size=0
*/
void* 	MPoolAlloc	(MPool* _mPool, int _size);


/*  given pointer to allocated data block _mem, return actual length of
	data in bytes (original requested size, not aligned to boundaries).
*/
int		MPoolGetSize	(void* _mem);


/*	Free memory blocks
	Input:	- _mPool
			- block to free
	Output: none
	if block does not belong to MPool: undefined behavior
	if block already free: may merge with following block(s)
*/
void	MPoolFree	(MPool* _mPool, void* _blockFree);

#endif /* __MPOOL_NEW_H__ */

