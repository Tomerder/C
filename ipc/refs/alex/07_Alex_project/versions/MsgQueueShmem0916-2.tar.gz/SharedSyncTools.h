/*******************************************************************************
    Author: Stav Ofer
    Creation date:  		2013-09-16    
    Last modified date:		2013-09-16
    Description: 	synchronization tools - mutex & semaphore, for use in shared memory.
					location of the semaphore/mutex is given by the user, and it is 
					assumed that a memory of the requred size is free at the given address.
					
					currently implemented with POSIX semaphore.
					note: link with -pthread flag
********************************************************************************/

#ifndef __SHARED_SYNC_TOOLS_H__
#define __SHARED_SYNC_TOOLS_H__


#ifndef _XOPEN_SOURCE
#define _XOPEN_SOURCE 500
#endif


#include <pthread.h>


typedef 	struct SharedSem 	SharedSem_t;
typedef 	struct SharedMutex 	SharedMutex_t;


/*** to C file ***/
/*
struct SharedSem
{
	sem_t	m_sem;
};

struct SharedMutex
{
	sem_t	m_mutex;
};
*/

/*----------------------------------------------------------------------*/
/*								SEMAPHORE								*/
/*----------------------------------------------------------------------*/

/* create a semaphore at given address. return ptr to semaphore, or NULL for error */
SharedSem_t*	SharedSemCreate		(void* _mem);

/* destroy semaphore. return ptr to now-free memory, or NULL for error */
void*			SharedSemDestroy	(SharedSem_t* _sem);


/* initialize semaphore to _value, return success (1) / fail (0) */ 
int		SharedSemInit	(SharedSem_t* _sem, size_t _value);

/* semaphore up (release), return success (1) / fail (0) */
int		SharedSemUp		(SharedSem_t* _sem);

/* semaphore down (lock), return success (1) / fail (0) */
/* if semaphore value is 0, calling process is blocked until that value increases */
int		SharedSemDown		(SharedSem_t* _sem);

/* return current value of semaphore, -1 for error */
int		SharedSemGetValue	(SharedSem_t* _sem);



/*----------------------------------------------------------------------*/
/*									MUTEX								*/
/*----------------------------------------------------------------------*/

/* create a mutex at given address. return ptr to mutex, or NULL for error */
SharedSem_t*	SharedMutexCreate		(void* _mem);

/* destroy mutex. return ptr to now-free memory, or NULL for error */
void*			SharedMutexDestroy		(SharedMutex_t* _mutex);


/* lock mutex, return success (1) / fail (0) */
int		SharedMutexLock		(SharedMutex_t* _mutex);

/* unlock mutex, return success (1) / fail (0) */
int		SharedMutexUnlock	(SharedMutex_t* _mutex);



#endif /* __SHARED_SYNC_TOOLS_H__ */



