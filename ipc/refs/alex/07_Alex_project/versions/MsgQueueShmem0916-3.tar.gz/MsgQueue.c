/*******************************************************************************
	Author:				Stav Ofer
	Creation date:		2013-09-16
	Date last modified:	2013-09-16
	Description:		Message Queue over Shared Memory in multi-process interlock
********************************************************************************/

#include <unistd.h>
#include <stdio.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <fcntl.h> 
#include <sys/shm.h>

/*#include <string.h>*/


#include "QueueNew.h"
#include "MPoolNew.h"
#include "SharedSyncTools.h"

#include "MsgQueue.h"




/*######################################################################*/
/*				DEFINITIONS & FOREWARD DECLARATIONS						*/
/*######################################################################*/





/* offset table - internal */
typedef struct OffsetTable
{
	size_t	m_sync;
	size_t	m_queue;
	size_t	m_pool;
} OffsetTable_t;

/* syncronization tools - internal */
typedef struct SyncTools
{
	SharedMutex_t	m_mutex;
	SharedSem_t		m_full;
	SharedSem_t		m_empty;
} SyncTools_t;


/*** Message Queue ***/
struct MQ
{
	SyncTools_t*	m_synctools;
	Queue*			m_queue;
	MPool*			m_messages;
	int				m_createFlag;
};







/*######################################################################*/
/*								API FUNCTIONS							*/
/*######################################################################*/


/*----------------------------------------------------------------------*/
/*					CREATE, CONNECT, DESTROY							*/
/*----------------------------------------------------------------------*/

MQ_t*	MsgQueueCreate	(char *_msgQueueName, size_t _msgMax, size_t _memSize)
{
	/*
	MQ_t* msgQ;
	int shmem;	/* file desc.
	OffsetTable_t*	table;
	
	assert( _msgQueueName && _msgMax && _memSize);
	
	*** get shared mem object:
	
		open sharedMem object - shmem = shm_open
			permissions: read & write to all
			check errors
	
		set size - ftruncate
			check errors
		map to process memory - mmap
			check errors
	
	*** offset table:
		create offset table at start of shmem, put offset of m_sync ( sizeof(OffsetTable_t) )
		and of m_queue ( m_sync + sizeof(SyncTools_t) )
	
	*** SyncTools:
		create msgQ->m_synctools in shmem
		initialize them with SharedSyncTools module API
		( semaphore values: empty - 0, full - _msgMax ??? )
		(check errors)
		
	*** queue:
		get req. size
		create msgQ->m_queue in shmem, initialize, check errors
		
		from size put offset of mpool in table
		
	*** MPool:
		create msgQ->m_pool in shmem, with the remaining size of shmem, check errors
	
	*** raise create flag
	
	return msgQ;
	*/
}
/*----------------------------------------------------------------------*/

/* connect to shared memory & create process/thread local metadata */
MQ_t*	MsgQueueConnect	(char *_msgQueueName)
{
	/*
	MQ_t* msgQ;
	int shmem;	/* file desc.
	OffsetTable_t*	table;
	
	assert( _msgQueueName );
	
	connect to shmem - shm_open
	map to process memory - mmap
			check errors
			
	cast start of shmem as table,
	set msgQ pointers according to table
	
	createFlag = 0;
	
	return msgQ;
	*/
}
/*----------------------------------------------------------------------*/

void	MsgQueueDestroy	(MQ_t *_msqQue)
{
	/*
	assert( _msqQue );
	
	if( createFlag == 1 )
		shm_unlink
	
	*/
}
/*----------------------------------------------------------------------*/


/*----------------------------------------------------------------------*/
/*				Message Manipulation: Send, Receive						*/
/*----------------------------------------------------------------------*/

/* return number of bytes actually written, 0 if message queue full		*/
int		MsgQueueSend	(MQ_t *_msgQue, void* _buffer, size_t _length)
{
	/*
	assert( _msqQue && _buffer && _length);
	
	lock mutex
	
	if( IsQueueFull )
		unlock mutex ?
		return 0 ?
	
	down( full semaphore )
	up( empty sem )
	
	allocate memory
		if not enough memory: ???
			up( full sem )
			down (empty)
			return 0
	
	copy message to allocated memory
	
	unlock mutex
	
	return # of bytes
	*/
}
/*----------------------------------------------------------------------*/

/* return number of bytes actually read, 0 if message queue unavailable */ 
int		MsgQueueRecv	(MQ_t *_msgQue, void* _buffer, size_t _size)
{
	/*
	assert( _msqQue && _buffer && _size);
	
	lock mutex
	
	if( IsQueueEmpty )
		unlock mutex ?
		return 0 ?
	
	up( full semaphore )
	down( empty sem )
	
	go to location of message (offset from QueueRemove)
	get message_size (MPoolGetBlockSize)
	
	if( message_size > _size) then message_size = _size
	copy message_size bytes of message to buffer 
	
	unlock mutex
	
	return message_size
	*/
}
/*----------------------------------------------------------------------*/



/*----------------------------------------------------------------------*/
/*								IsEmpty									*/
/*----------------------------------------------------------------------*/
int		IsMsgQueueEmpty (MQ_t *_msgQue)
{
	/*
	return IsQueueEmpty(_msgQue->m_queue);
	*/
}
/*----------------------------------------------------------------------*/


/*----------------------------------------------------------------------*/
/* Utility Functions for debugging and unit testing */
/*----------------------------------------------------------------------*/
void	MsgQueuePrint	(MQ_t* _msgQue)
{
	/**/
}
/*----------------------------------------------------------------------*/



/*######################################################################*/
/*							INTERNAL FUNCTIONS							*/
/*######################################################################*/




