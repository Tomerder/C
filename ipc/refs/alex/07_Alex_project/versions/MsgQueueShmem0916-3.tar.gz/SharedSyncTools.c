/*******************************************************************************
    Author: Stav Ofer
    Creation date:  		2013-09-16    
    Last modified date:		2013-09-16
    Description: 	synchronization tools - mutex & semaphore, for use in shared memory.
					location of the semaphore/mutex is given by the user, and it is 
					assumed that a memory of the requred size is free at the given address.
					
					currently implemented with POSIX semaphore.
					note: link with -pthread flag
********************************************************************************/

#include <stdio.h>
#include <errno.h>
#include <semaphore.h>
#include <pthread.h>

#include "SharedSyncTools.h"


/*######################################################################*/
/*				DEFINITIONS & FOREWARD DECLARATIONS						*/
/*######################################################################*/





struct SharedSem
{
	sem_t	m_sem;
};

struct SharedMutex
{
	sem_t	m_mutex;
	
	/* owner ?? */
};





/*######################################################################*/
/*								SEMAPHORE								*/
/*######################################################################*/

/*----------------------------------------------------------------------*/
/* create a semaphore at given address & initialize to _initValue.
	return ptr to semaphore, or NULL for error */
SharedSem_t*	SharedSemCreate		(void* _mem, size_t _initValue)
{
	SharedSem_t* sem = (SharedSem_t*)_mem;
	
	assert(_mem);
	
	sem_init(sem, 1, _initValue);
	/* check for errors */
	
	return sem;
}
/*----------------------------------------------------------------------*/


/*----------------------------------------------------------------------*/
/* destroy semaphore. return ptr to now-free memory, or NULL for error */
void*			SharedSemDestroy	(SharedSem_t* _sem)
{
	sem_destroy(_sem);
	/* check for errors */
	
	/* return *** */
}
/*----------------------------------------------------------------------*/


/*----------------------------------------------------------------------*/
/* semaphore up (release), return success (1) / fail (0) */
int		SharedSemUp		(SharedSem_t* _sem)
{
	sem_post(_sem);
	/* check for errors */
	
	/* return *** */
}
/*----------------------------------------------------------------------*/


/*----------------------------------------------------------------------*/
/* semaphore down (lock), return success (1) / fail (0) */
/* if semaphore value is 0, calling process is blocked until that value increases */
int		SharedSemDown		(SharedSem_t* _sem)
{
	sem_wait(_sem);
	/* check for errors */
	
	/* return *** */
}
/*----------------------------------------------------------------------*/


/*----------------------------------------------------------------------*/

/* return current value of semaphore, -1 for error */
int		SharedSemGetValue	(SharedSem_t* _sem)
{
	int value;
	
	sem_getvalue(_sem, &value);
	/* check for errors */
	
	return value;
}
/*----------------------------------------------------------------------*/




/*######################################################################*/
/*								MUTEX									*/
/*######################################################################*/

/* create a mutex at given address. return ptr to mutex, or NULL for error */
SharedMutex_t*	SharedMutexCreate		(void* _mem)
{
	SharedMutex_t* mutex = (SharedMutex_t*)_mem;;
	
	assert(_mem);
	
	sem_init(mutex, 1, 1);
	/* check for errors */
	
	/* owner ?? */
	
	return mutex;
}
/*----------------------------------------------------------------------*/


/*----------------------------------------------------------------------*/
/* destroy mutex. return ptr to now-free memory, or NULL for error */
void*			SharedMutexDestroy		(SharedMutex_t* _mutex);
{
	sem_destroy(_mutex);
	/* check for errors */
	
	/* return *** */
}
/*----------------------------------------------------------------------*/


/*----------------------------------------------------------------------*/
/* lock mutex, return success (1) / fail (0) */
int		SharedMutexLock		(SharedMutex_t* _mutex)
{
	sem_wait(_mutex);
	/* check for errors */
	
	/* return *** */
}
/*----------------------------------------------------------------------*/


/*----------------------------------------------------------------------*/
/* unlock mutex, return success (1) / fail (0) */
int		SharedMutexUnlock	(SharedMutex_t* _mutex)
{
	int value;
	
	sem_getvalue(_mutex, &value);
	/* check for errors */
	
	if(value > 0) {
		/* return 0 ??? */
	}
	
	sem_post(_mutex);
	/* check for errors */
	
	/* return *** */
}
/*----------------------------------------------------------------------*/



