/*******************************************************************************
    Author: Stav Ofer
    Creation date:  		2013-06-16    
    Last modified date:		2013-09-16
    Description:	functions for handling queues.
    				update 16/9: modified for use as part of message queue.
********************************************************************************/

/*#include <stdlib.h>*/
#include <stdio.h>
#include <string.h>
#include <assert.h>

#include "QueueNew.h"



/*######################################################################*/
/*					Definitions & Foreward Declarations					*/
/*######################################################################*/

struct Queue
{
	size_t	m_head;		/* index of current head of queue - first/oldest inserted item	*/
	size_t	m_tail;		/* index of current tail of queue - next empty place after last/newest	*/
	size_t	m_noItems;	/* number of items						*/
	size_t	m_size;		/* size of array - constant 			*/
	size_t	m_items;	/* (start of) array of items (offsets)	*/
};





/*######################################################################*/
/*								API Fucntions							*/
/*######################################################################*/


/* create queue of size _nPlaces, starting at given memory address */
/* return NULL for failure */
Queue*	QueueCreate		(void* _memory, size_t _nPlaces)
{
	/*
	Queue* queue = (Queue*)_memory;
	
	assert( _memory && _nPlaces);
	
	queue->m_head 		= 0;
	queue->m_tail 		= 0;
	queue->m_noItems 	= 0;
	queue->m_size 		= _nPlaces;
	
	memset(queue->m_items, 0, sizeof(size_t) * _nPlaces);
	
	return queue;
	*/
}

/* return pointer to now-free memory */
void*	QueueDestroy	(Queue* _queue)
{
	/*
	memset(_queue, 0, sizeof(Queue) + sizeof(size_t) * (_queue->m_items - 1) );
	return (void*) _queue;
	*/
}


/* return required memory size for given _nPlaces */
size_t	QueueGetSize	(size_t _nPlaces)
{
	/* return sizeof(Queue) + sizeof(size_t) * (_nPlaces - 1);	*/
}


/* insert to queue tail, return success (1) / fail (0) */
/*int		QueueInsert		(Queue* _q, int _item)*/
/*{*/

/*}*/

/* remove from queue head, return success (1) / fail (0) */
/*int		QueueRemove		(Queue* _q, int* _item)*/
/*{*/

/*}*/


/* return true (1) / false (0) */
/*int		IsQueueEmpty	(Queue* _q)*/
/*{*/

/*}*/

/*int		IsQueueFull		(Queue* _q)*/
/*{*/

/*}*/


/* for testing purposes */
/*void	QueuePrint		(Queue* _q)*/
/*{*/

/*}*/







