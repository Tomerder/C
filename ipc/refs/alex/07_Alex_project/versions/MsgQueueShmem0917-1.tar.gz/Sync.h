/*******************************************************************************
    Author: Stav Ofer
    Creation date:  		2013-09-17    
    Last modified date:		2013-09-17
    Description: 	synchronization tools - mutex & semaphore, for use in shared memory.
									
					currently implemented with POSIX semaphore.
						note: no destroy function b/c posix sem is on shared mem.
						note: link with -pthread flag
********************************************************************************/

#ifndef __SYNC_H__
#define __SYNC_H__


#ifndef _XOPEN_SOURCE
#define _XOPEN_SOURCE 500
#endif


#include <pthread.h>


typedef struct Sync Sync_t;


/*----------------------------------------------------------------------*/
/*								SYNC									*/
/*----------------------------------------------------------------------*/

/* create sync struct at address, return NULL for errors */
Sync*	SyncCreate	(void* _addr, int _size, int* _types, int* _initVals);

/* return # of bytes needed for Sync */
size_t	SyncGetSize	(int _num);

/* return address of item # _num */
SyncTool_t*	SyncAttach	(Sync* _sync, int _num);


/*----------------------------------------------------------------------*/
/*								SEMAPHORE								*/
/*----------------------------------------------------------------------*/



void	SyncSemUp		(SyncTool_t* _sem);

void	SyncSemDown		(SyncTool_t* _sem);

int		SyncSemGetVal	(SyncTool_t* _sem);


/*----------------------------------------------------------------------*/
/*								MUTEX									*/
/*----------------------------------------------------------------------*/


void	SyncMutexLock	(SyncTool_t* _mutex);

void	SyncMutexUnlock	(SyncTool_t* _mutex);


#endif /* __SYNC_H__ */
