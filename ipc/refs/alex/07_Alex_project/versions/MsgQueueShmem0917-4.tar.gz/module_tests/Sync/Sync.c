/*******************************************************************************
    Author: Stav Ofer
    Creation date:  		2013-09-17    
    Last modified date:		2013-09-17
    Description: 	synchronization tools - mutex & semaphore, for use in shared memory.
									
					currently implemented with POSIX semaphore.
						note: no destroy function b/c posix sem is on shared mem.
						note: link with -pthread flag
********************************************************************************/

#include <stdio.h>
#include <errno.h>
#include <semaphore.h>
#include <pthread.h>
#include <assert.h>

#include "Sync.h"




/*######################################################################*/
/*				DEFINITIONS & FOREWARD DECLARATIONS						*/
/*######################################################################*/


enum Success
{
	SUCCESS = 0,
	FAIL = -1
};


enum SyncType
{
	UNDEFINED,
	SEMAPHORE,
	MUTEX
};


struct SyncTool
{
	int		m_type;
	sem_t	m_tool;
};


struct Sync
{
	size_t		m_nItems;
	SyncTool_t	m_toolArray[1];
};



/*######################################################################*/
/*							API FUNCTIONS								*/
/*######################################################################*/



/*######################################################################*/
/*								SYNC									*/
/*######################################################################*/


/*----------------------------------------------------------------------*/
/* create sync struct at address, return NULL for errors */
Sync_t*	SyncCreate	(void* _addr, int _nItems, int* _initVals)
{
	Sync_t* newSync = (Sync_t*)_addr;
	int i;
	
	assert( _addr && _nItems && _initVals );
	
	for(i=0; i<_nItems; ++i)
	{
/*		newSync->m_toolArray[i].m_tool;*/
		sem_init( &newSync->m_toolArray[i].m_tool, 1, _initVals[i]);
/* check errors */
		newSync->m_toolArray[i].m_type = UNDEFINED;
	}
	
	return newSync;
}
/*----------------------------------------------------------------------*/

/*----------------------------------------------------------------------*/
/* destroy - currently empty */
void	SyncDestroy(Sync_t* _sync)
{
}
/*----------------------------------------------------------------------*/

/*----------------------------------------------------------------------*/
/* return # of bytes needed for Sync */
size_t	SyncGetSize	(int _nItems)
{
	return ( sizeof(Sync_t) + sizeof(SyncTool_t) * (_nItems-1) );
}
/*----------------------------------------------------------------------*/

/*----------------------------------------------------------------------*/
/* return address of item # _num */
SyncTool_t*	SyncAttach	(Sync_t* _sync, int _num)
{
	return (SyncTool_t*)( _sync + sizeof(Sync_t) + sizeof(SyncTool_t) * (_num-1) );
}
/*----------------------------------------------------------------------*/
/*----------------------------------------------------------------------*/


/*######################################################################*/
/*								SEMAPHORE								*/
/*######################################################################*/

/*----------------------------------------------------------------------*/
/* return success (0) / fail (-1) */
int		SyncSemUp		(SyncTool_t* _sem)
{
	assert(_sem);
	
	if( _sem->m_type != SEMAPHORE )
	{
		if( _sem->m_type != UNDEFINED ) {
			return FAIL;
		}
		_sem->m_type = SEMAPHORE;
	}
	
	return sem_post(&_sem->m_tool);
}
/*----------------------------------------------------------------------*/

/*----------------------------------------------------------------------*/
int		SyncSemDown		(SyncTool_t* _sem)
{
	assert(_sem);
	
	if( _sem->m_type != SEMAPHORE )
	{
		if( _sem->m_type != UNDEFINED ) {
			return FAIL;
		}
		_sem->m_type = SEMAPHORE;
	}
	
	return sem_wait(&_sem->m_tool);
}
/*----------------------------------------------------------------------*/

/*----------------------------------------------------------------------*/
/* return semaphore value or -1 for error */
int		SyncSemGetVal	(SyncTool_t* _sem)
{
	int value;
	
	assert(_sem);
	
	if( sem_getvalue(&_sem->m_tool, &value) < 0) {
		return FAIL;
	}
	
	return value;
}
/*----------------------------------------------------------------------*/
/*----------------------------------------------------------------------*/


/*######################################################################*/
/*								MUTEX									*/
/*######################################################################*/

/*----------------------------------------------------------------------*/
int		SyncMutexLock	(SyncTool_t* _mutex)
{
	assert(_mutex);
	
	if( _mutex->m_type != MUTEX )
	{
		if( _mutex->m_type != MUTEX ) {
			return FAIL;
		}
		_mutex->m_type = MUTEX;
	}
	
	return sem_wait(&_mutex->m_tool);
}
/*----------------------------------------------------------------------*/

/*----------------------------------------------------------------------*/
int		SyncMutexUnlock	(SyncTool_t* _mutex)
{
	assert(_mutex);
	
	if( _mutex->m_type != MUTEX )
	{
		if( _mutex->m_type != MUTEX ) {
			return FAIL;
		}
		_mutex->m_type = MUTEX;
	}
	
	return sem_post(&_mutex->m_tool);
}
/*----------------------------------------------------------------------*/
/*----------------------------------------------------------------------*/


