/*******************************************************************************
    Author: Stav Ofer
    Creation date:  		2013-09-17    
    Last modified date:		2013-09-17
    Description: 	shared memory functions
********************************************************************************/

#ifndef __SHARED_MEM_H__
#define __SHARED_MEM_H__


/* create/connct to shared memory segment, returns process-specific address */
void*	ShmemGet	(key_t _key, size_t _size, int _flags);

/* disconnect from shared memory */
void	ShmemDisconnect	(void* _shmem);

/* destroy (takes effect only after all processes are disconnected */
void	ShmemDestroy (void* _shmem);



#endif /* __SHARED_MEM_H__ */
