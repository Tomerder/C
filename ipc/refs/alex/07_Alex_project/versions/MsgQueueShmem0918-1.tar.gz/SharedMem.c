/*******************************************************************************
    Author: Stav Ofer
    Creation date:  		2013-09-17    
    Last modified date:		2013-09-18
    Description: 	shared memory functions
********************************************************************************/

#ifndef _XOPEN_SOURCE
#define _XOPEN_SOURCE 600
#endif


#include <unistd.h>
#include <stdio.h>
#include <assert.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/ipc.h> 
#include <sys/shm.h>

#include "SharedMem.h"


/*######################################################################*/
/*				DEFINITIONS & FOREWARD DECLARATIONS						*/
/*######################################################################*/

#define		HANDLE_ERRNO(X,S,R)			if(-1 == (X)) { perror(S); return(R); }
#define		HANDLE_ERRNO_VOID(X,S,R)	if((void*)-1 == (X)) { perror(S); return(R); }
#define		HANDLE_ERRNO_NOR(X,S)			if(-1 == (X)) { perror(S); return; }


/*######################################################################*/
/*							API FUNCTIONS								*/
/*######################################################################*/

/*----------------------------------------------------------------------*/
/* create/connct to shared memory segment, returns process-specific address */
/* or NULL for error */
void*	ShmemConnect	(const char* _name, int _keygen, size_t _size, int _flags)
{
	void* shmem;
	key_t key;
	int shmid;
	
	assert(_name && _keygen && _size);
	
	/* generate key & get shared mem segment ID */
	
	key = ftok(_name, _keygen);
	HANDLE_ERRNO(key, "ShmemConnect", NULL);
	
	shmid = shmget(key, _size, _flags);
	HANDLE_ERRNO(shmid, "ShmemConnect", NULL);
	
	/* attach & get address */
	
	shmem = shmat(shmid, 0, 0);
	HANDLE_ERRNO_VOID(shmem, "ShmemConnect", NULL);
	
	return shmem;
}
/*----------------------------------------------------------------------*/


/*----------------------------------------------------------------------*/
/* disconnect from shared memory, and destroy if _destroy = true */
/* ( destroy takes effect only after all processes are disconnected ) */
void	ShmemDisconnect	(void* _shmem, int _shmid, int _destroy)
{
	int error;
	
	assert(_shmem);
	
	/* detach */
	error = shmdt(_shmem);
	HANDLE_ERRNO_NOR(error, "ShmemDisconnect");
	
	/* destroy */
	if(_destroy)
	{
		error = shmctl(_shmid, IPC_RMID, NULL);
		HANDLE_ERRNO_NOR(error, "ShmemDisconnect");
	}
}
/*----------------------------------------------------------------------*/
/*----------------------------------------------------------------------*/




