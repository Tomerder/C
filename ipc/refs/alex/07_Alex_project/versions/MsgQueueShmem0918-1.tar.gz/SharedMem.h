/*******************************************************************************
    Author: Stav Ofer
    Creation date:  		2013-09-17    
    Last modified date:		2013-09-18
    Description: 	shared memory functions
********************************************************************************/

#ifndef __SHARED_MEM_H__
#define __SHARED_MEM_H__


/* create/connct to shared memory segment, returns process-specific address */
/* or NULL for error */
void*	ShmemConnect	(const char* _name, int _keygen, size_t _size, int _flags);

/* disconnect from shared memory, and destroy if _destroy = true */
/* ( destroy takes effect only after all processes are disconnected ) */
void	ShmemDisconnect	(void* _shmem, int _shmid, int _destroy);


#endif /* __SHARED_MEM_H__ */
