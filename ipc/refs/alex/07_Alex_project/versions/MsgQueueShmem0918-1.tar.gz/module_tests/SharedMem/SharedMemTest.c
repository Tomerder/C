/*******************************************************************************
    Author: Stav Ofer
    Creation date:  		2013-09-18    
    Last modified date:		2013-09-18
    Description: 	some tests for shared memory module
********************************************************************************/

#include <stdio.h>

#include "SharedMem.h"




int main()
{
	
	
	
	return 0;
}



