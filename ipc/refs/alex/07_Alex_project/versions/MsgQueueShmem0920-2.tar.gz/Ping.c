/*******************************************************************************
    Author:					Stav Ofer
    Creation date:  		2013-09-20    
    Last modified date:		2013-09-20
    Description: 	Test for Message Queue over Shared Memory - ping
********************************************************************************/

#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <pthread.h>

#include "MsgQueue.h"
#include "PingPong.h"


/*######################################################################*/
/*				definitions & foreward declarations						*/
/*######################################################################*/


#define HANDLE_ERR(X)		fprintf(stderr, "%s:%d Error: %s\n", __FILE__, __LINE__, X); return -1

#define MAXSIZE				32
#define PAGESIZE			getpagesize()


static const char* defMsg = "This message is 32 characters AB";
static const char* byeMsg = "Bye";

/*######################################################################*/
/*									MAIN								*/
/*######################################################################*/
int main(int argc, char *argv[])
{
	Options_t options;				/* runtime options	*/
	MQ_t* myMQ = NULL;
	MQ_t* handshakeMQ = NULL;
	sem_t semPing;
	char outMsg[MAXSIZE+1];
	int nToSend = 0;
	int nSent = 0;
	int nPongs = 0;
	int pid;
	
	/* initialize & handle runtime options */
	OptHandler(argc, argv, &options);
	
	/* initialize ping semaphore to 0 */
	if( -1 == sem_init(&semPing, 1, 0) {
		HANDLE_ERR("sem_init");
	}
	
	/* FORK */
	pid = fork();
	
	if(pid < 0)	{	/* fork failed */
		HANDLE_ERR("fork");
	}
	
	/* CHILD - handshakes */
	else if( pid > 0 )
	{	
		char inHandShake[MAXSIZE];
		int length;
		
		/* create handshake queue */
		handshakeMQ = MsgQueueCreate( options->m_fileHandshake, options->m_queueSize, PAGESIZE);	/* different queue size? */
		if( !handshakeMQ ) {
			HANDLE_ERR("MsgQueueCreate");
		}
		
		
		/* read 1st handshake */
		
		length = MsgQueueRecv( handshakeMQ, inHandShake, MAXSIZE);
		if( 0 == length ) {
			HANDLE_ERR("MsgQueueRecv (handshake)");
		}
		
		nToSend += options->m_nMessages;
		++nPongs;
		
		if( -1 == sem_post(&semPing) ) {
			HANDLE_ERR("semPost");
		}
		
		/* continue while parent still active */
		while( nSent < nToSend )
		{
			length = MsgQueueRecv( handshakeMQ, inHandShake, MAXSIZE);
			if( 0 == length ) {
				HANDLE_ERR("MsgQueueRecv (handshake)");
			}
		
			nToSend += options->m_nMessages;
			++nPongs;
		} /* end while */
		
		MsgQueueDestroy( handshakeMQ );
		
		return 0;
	}	/* end child */
	
	else	/* PARENT - actual messages */
	{
		int length;
		int sent;
		
		/* create message queue */
		myMQ = MsgQueueCreate( options->m_filename, options->m_queueSize, PAGESIZE);
		if( !myMQ ) {
			HANDLE_ERR("MsgQueueCreate");
		}
		
		/* wait for 1st pong to arrive */
		if( -1 == sem_wait(&semPing) ) {
			HANDLE_ERR("semPost");
		}
		
		srand(time(0));
		
		/* send messages wiht random length */
		while( nSent < nToSend )
		{
			length = rand()%MAXSIZE + 1;
			memcpy( outMsg, defMsg, length );
			
			sent = MsgQueueSend( myMQ, outMsg, length );
			if( 0 == sent ) {
				HANDLE_ERR("MsgQueueSend");
			}
			
			++nSent;
			
			outMsg[sent] = '\0';
			printf("Ping: sent msg # %d: %s\n", nSent, outMsg);
		}	/* end while */
		
		/* send bye-bye message */
		length = strlen(byeMsg);
		memcpy( outMsg, byeMsg, length );
		
		sent = MsgQueueSend( myMQ, outMsg, length );
		if( 0 == sent ) {
			HANDLE_ERR("MsgQueueSend");
		}
		
		++nSent;
		
		outMsg[sent] = '\0';
		printf("Ping: sent msg # %d: %s\n", nSent, outMsg);
	
		/* destroy myMQ */
		MsgQueueDestroy( myMQ );
		
		return 0;
	}	/* end parent */
	
	/* wait pid ? */
	
	
	return 0;
}
/*######################################################################*/






