/*******************************************************************************
    Author:					Stav Ofer
    Creation date:  		2013-09-20    
    Last modified date:		2013-09-20
    Description: 	Test for Message Queue over Shared Memory - pong
********************************************************************************/

#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <pthread.h>

#include "MsgQueue.h"
#include "PingPong.h"


/*######################################################################*/
/*				definitions & foreward declarations						*/
/*######################################################################*/


#define HANDLE_ERR(X)		fprintf(stderr, "%s:%d Error: %s\n", __FILE__, __LINE__, X); return -1
#define MAXSIZE				32

static const char* handshake = "Hello";
static const char* byeMsg = "Bye";


/*######################################################################*/
/*									MAIN								*/
/*######################################################################*/
int main(int argc, char *argv[])
{
	Options_t options;				/* runtime options	*/
	MQ_t* myMQ = NULL;
	MQ_t* handshakeMQ = NULL;
	sem_t* semPing = NULL;
	char inMsg[MAXSIZE];
	int nReceived = 0;
	
	/* initialize & handle runtime options */
	OptHandler(argc, argv, &options);
	
	/* connect to message queue & handshake queue */
	
	myMQ = MsgQueueConnect(options->m_filename);
	if( !myMQ ) {
		HANDLE_ERR("MsgQueueConnect");
	}
	
	handshakeMQ = MsgQueueConnect(options->m_fileHandshake);
	if( !handshakeMQ ) {
		HANDLE_ERR("MsgQueueConnect");
	}
	
	
	/* send handshake to handshakeMQ */
	
	
	/* read 1st msg */

	/* loop: while msg != bye */
	
		/* sleep */
		/* read */
	
	
	/* resend bye */
	/* disconnect from myMQ & handshakeMQ */
	
	
	
	
	
	return 0;
}
/*######################################################################*/


