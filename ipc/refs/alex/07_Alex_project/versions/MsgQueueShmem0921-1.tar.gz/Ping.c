/*******************************************************************************
    Author:					Stav Ofer
    Creation date:  		2013-09-20    
    Last modified date:		2013-09-21
    Description: 	Test for Message Queue over Shared Memory - ping
********************************************************************************/

#ifndef _XOPEN_SOURCE
#define _XOPEN_SOURCE 500
#endif

#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <semaphore.h>
#include <pthread.h>

#include "MsgQueue.h"
#include "PingPong.h"


/*######################################################################*/
/*				definitions & foreward declarations						*/
/*######################################################################*/


#define HANDLE_ERR(X)		fprintf(stderr, "%s:%d Error: %s\n", __FILE__, __LINE__, X); return -1

#define VERBOSE(X)			if(options.m_verbose) { printf("%s", X); }
#define VERBOSE_INT(X,Y,Z)	if(options.m_verbose) { printf("%s %d %s", X,Y,Z); }

#define MAXSIZE				32
#define PAGESIZE			getpagesize()


static char* defMsg = "This message is 32 characters AB";
static char* byeMsg = "Bye";

/*######################################################################*/
/*									MAIN								*/
/*######################################################################*/
int main(int argc, char *argv[])
{
	Options_t options;				/* runtime options	*/
	MQ_t* myMQ = NULL;				/* message queue	*/
	MQ_t* handshakeMQ = NULL;		/* handshake msgQ	*/
	sem_t semPing;					/* synchronize handshake-reading process & msg sending process */
	char outMsg[MAXSIZE+1];			/* outgoing buffer 	*/
	int nToSend = 0;				/* total # of msgs to send (updated when more pongs enter) */
	int nSent = 0;					/* # of msgs sent	*/
	int nPongs = 0;					/* # of pongs		*/
	int pid;						/* process id (of handshake-reader) */
	
	/* initialize & handle runtime options */
	OptHandler(argc, argv, &options);
	
	/* initialize ping semaphore to 0 */
	if( -1 == sem_init(&semPing, 1, 0) ) {
		HANDLE_ERR("sem_init");
	}
	VERBOSE("Ping: initialized semaphore\n");
	
	/* FORK */
	pid = fork();
	
	if(pid < 0)	{	/* fork failed */
		HANDLE_ERR("fork");
	}
	
	/* CHILD - handshakes */
	else if( pid > 0 )
	{	
		char inHandShake[MAXSIZE];
		int length;
		
		/* create handshake queue */
		handshakeMQ = MsgQueueCreate( options.m_fileHandshake, options.m_queueSize, PAGESIZE);	/* different queue size? */
		if( !handshakeMQ ) {
			HANDLE_ERR("MsgQueueCreate");
		}
		
		VERBOSE("Ping child: created handshake queue\n");
		
		/* read 1st handshake */
		
		length = MsgQueueRecv( handshakeMQ, inHandShake, MAXSIZE);
		if( 0 == length ) {
			HANDLE_ERR("MsgQueueRecv (handshake)");
		}
		
		nToSend += options.m_nMessages;
		++nPongs;
		VERBOSE("Ping child: read 1st handshake & raised semaphore\n");
		
		if( -1 == sem_post(&semPing) ) {
			HANDLE_ERR("semPost");
		}
		
		/* continue while parent still active */
		while( nSent < nToSend )
		{
			length = MsgQueueRecv( handshakeMQ, inHandShake, MAXSIZE);
			if( 0 == length ) {
				HANDLE_ERR("MsgQueueRecv (handshake)");
			}
		
			nToSend += options.m_nMessages;
			++nPongs;
			VERBOSE_INT("Ping child: read handshake #", nPongs, "\n");
		} /* end while */
		
		MsgQueueDestroy( handshakeMQ );
		VERBOSE("Ping child: destroyed handshake queue\n");
		
		return 0;
	}	/* end child */
	
	/* PARENT - actual messages */
	else
	{
		int length;
		int sent;
		
		/* create message queue */
		myMQ = MsgQueueCreate( options.m_filename, options.m_queueSize, PAGESIZE);
		if( !myMQ ) {
			HANDLE_ERR("MsgQueueCreate");
		}
		VERBOSE("Ping parent: created message queue\n");
		
		/* wait for 1st pong to arrive */
		if( -1 == sem_wait(&semPing) ) {
			HANDLE_ERR("semPost");
		}
		VERBOSE("Ping parent: notified of 1st pong\n");
		
		srand(time(0));
		
		/* send messages wiht random length */
		while( nSent < nToSend )
		{
			length = rand()%MAXSIZE + 1;
			memcpy( outMsg, defMsg, length );
			
			sent = MsgQueueSend( myMQ, outMsg, length );
			if( 0 == sent ) {
				HANDLE_ERR("MsgQueueSend");
			}
			
			++nSent;
			
			outMsg[sent] = '\0';
			printf("Ping: sent msg # %d: %s\n", nSent, outMsg);
		}	/* end while */
		
		/* send bye-bye message */
		length = strlen(byeMsg);
		sent = MsgQueueSend( myMQ, byeMsg, length );
		if( 0 == sent ) {
			HANDLE_ERR("MsgQueueSend");
		}
		
		++nSent;
		
		outMsg[sent] = '\0';
		printf("Ping: sent msg # %d: %s\n", nSent, outMsg);
	
		/* destroy myMQ */
		MsgQueueDestroy( myMQ );
		VERBOSE("Ping parent: destroyed message queue\n");
		
		return 0;
	}	/* end parent */
	
	/* wait pid ? */
	
	
	return 0;
}
/*######################################################################*/






