/*******************************************************************************
    Author:					Stav Ofer
    Creation date:  		2013-09-20    
    Last modified date:		2013-09-21
    Description: 	Test for Message Queue over Shared Memory - pong
********************************************************************************/

#ifndef _XOPEN_SOURCE
#define _XOPEN_SOURCE 500
#endif

#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <pthread.h>
#include <sys/types.h>

#include "MsgQueue.h"
#include "PingPong.h"


/*######################################################################*/
/*				definitions & foreward declarations						*/
/*######################################################################*/


#define HANDLE_ERR(X)		fprintf(stderr, "%s:%d Error: %s\n", __FILE__, __LINE__, X); return -1

#define VERBOSE_INT(X,Y,Z)	if(options.m_verbose) { printf("%s %d %s", X,Y,Z); }

#define MAXSIZE				32

static char* handshake = "Hello";
static char* byeMsg = "Bye";


/*######################################################################*/
/*									MAIN								*/
/*######################################################################*/
int main(int argc, char *argv[])
{
	Options_t options;				/* runtime options		*/
	MQ_t* myMQ = NULL;				/* message queue		*/
	MQ_t* handshakeMQ = NULL;		/* handshake msgQ		*/
	char inMsg[MAXSIZE+1];			/* reading buffer		*/
	int nReceived = 0;				/* # of msgs received	*/
	int length;						/* length of message	*/
	int pid = getpid();				/* process id			*/
	
	/* initialize & handle runtime options */
	OptHandler(argc, argv, &options);
	
	/* connect to message queue & handshake queue */
	
	myMQ = MsgQueueConnect(options.m_filename);
	if( !myMQ ) {
		HANDLE_ERR("MsgQueueConnect");
	}
	VERBOSE_INT("Pong", pid, ": connected to message queue\n");
	
	handshakeMQ = MsgQueueConnect(options.m_fileHandshake);
	if( !handshakeMQ ) {
		HANDLE_ERR("MsgQueueConnect");
	}
	VERBOSE_INT("Pong", pid, ": connected to handshake queue\n");
	
	/* send handshake */
	length = strlen(handshake);
	length = MsgQueueSend( handshakeMQ, handshake, length );
	if( 0 == length ) {
		HANDLE_ERR("MsgQueueSend");
	}
	printf("Pong %d: sent handshake\n", pid);
	
	do {
		length = MsgQueueRecv( myMQ, inMsg, MAXSIZE);
		if( 0 == length ) {
			HANDLE_ERR("MsgQueueRecv");
		}
		
		++nReceived;
		
		inMsg[length] = '\0';
		printf("Pong %d: received msg #%d: %s\n", pid, nReceived, inMsg);
		
		sleep(options.m_sleep);
		
	} while ( 0 != strcmp(inMsg, byeMsg) );
	
	printf("Pong %d: received byebye, exiting\n", pid);
	
	/* resend bye msg */
	length = strlen(byeMsg);
	length = MsgQueueSend( myMQ, byeMsg, length );
	if( 0 == length ) {
		HANDLE_ERR("MsgQueueSend");
	}
	VERBOSE_INT("Pong", pid, ": resent byebye msg\n");
	
	/* disconnect from msg queues */
	MsgQueueDestroy(myMQ);
	MsgQueueDestroy(handshakeMQ);
	VERBOSE_INT("Pong", pid, ": disconnected from queues\n");
	
	return 0;
}
/*######################################################################*/


