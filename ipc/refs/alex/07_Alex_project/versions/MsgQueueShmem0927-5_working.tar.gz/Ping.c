/*******************************************************************************
    Author:					Stav Ofer
    Creation date:  		2013-09-20    
    Last modified date:		2013-09-21
    Description: 	Test for Message Queue over Shared Memory - ping
********************************************************************************/

#ifndef _XOPEN_SOURCE
#define _XOPEN_SOURCE 500
#endif

#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <pthread.h>
#include <sys/ipc.h>
#include <sys/types.h>
#include <sys/wait.h>

#include "SharedMem.h"
#include "Sync.h"
#include "MsgQueue.h"
#include "PingPong.h"


/*######################################################################*/
/*				definitions & foreward declarations						*/
/*######################################################################*/


#define HANDLE_ERR(X)		fprintf(stderr, "%s:%d Error: %s\n", __FILE__, __LINE__, X); return -1

#define VERBOSE(X)			if(options.m_verbose) { printf("%s", X); }
#define VERBOSE_INT(X,Y,Z)	if(options.m_verbose) { printf("%s %d %s", X,Y,Z); }

#define MAXSIZE				32
#define PAGESIZE			getpagesize()


typedef struct PingSharedData
{
	int		m_nPongs;	/* # of pongs		*/
	int		m_nToSend;	/* total # of msgs to send (updated when more pongs enter) */
	int		m_nSent;	/* # of msgs sent	*/
	
} PingSharedData_t;


static char* fileShmem = "SharedMem.c";
static int keygenShmem = 42;


static char* defMsg = "This message is 32 characters AB";
static char* byeMsg = "Bye";


/*######################################################################*/
/*									MAIN								*/
/*######################################################################*/
int main(int argc, char *argv[])
{
	Options_t options;				/* runtime options	*/
	MQ_t* myMQ = NULL;				/* message queue	*/
	MQ_t* handshakeMQ = NULL;		/* handshake msgQ	*/
	char outMsg[MAXSIZE+1];			/* outgoing buffer 	*/
	int pid;						/* process id (of handshake-reader) */
	
	int pingShmid;						/* shared memory for ping parent & child */
	void* pingShmem = NULL;				/* " */
	PingSharedData_t* pingData = NULL;	/* data in shared mem */
	Sync_t*	pingSync = NULL;			/* synchronize handshake-reading process & msg sending process */
	SyncTool_t* pingMutex = NULL;		/* " */
	int syncInitVal = 0;				/* mutex starts as locked */
	
	
	/* initialize & handle runtime options */
	OptHandler(argc, argv, &options);

	/* get shared mem for ping processes */
	pingShmid = ShmemGet(fileShmem, keygenShmem, PAGESIZE, IPC_CREAT);
	pingShmem = ShmemConnect(pingShmid, 0);
	
	/* initialize */
	pingData = (PingSharedData_t*)pingShmem;
	pingData->m_nPongs = 0;
	pingData->m_nToSend = 0;
	pingData->m_nSent = 0;
	
	/* initialize ping semaphore to 0 */
	pingSync = SyncCreate( (char*)pingShmem + sizeof(PingSharedData_t) , 1, &syncInitVal);
	VERBOSE("Ping: initialized semaphore\n");
	
	
/* FORK */
	pid = fork();
	
	if(pid < 0)	{	/* fork failed */
		HANDLE_ERR("fork");
	}
	
/*** CHILD - handshakes ***/
	else if( 0 == pid )
	{	
		char inHandShake[MAXSIZE];
		int length;
		void* pingShmem;
		
		/* attach all shared variables to correct address in this process */
		pingShmem = ShmemConnect(pingShmid, 0);
		pingData = (PingSharedData_t*)pingShmem;
		pingSync = (Sync_t*)((char*)pingShmem + sizeof(PingSharedData_t));
		pingMutex = SyncAttach(pingSync, 0);
		
		/* create handshake queue */
		handshakeMQ = MsgQueueCreate( options.m_fileHandshake, options.m_queueSize, PAGESIZE);	/* different queue size? */
		if( !handshakeMQ ) {
			HANDLE_ERR("MsgQueueCreate");
		}
		
		VERBOSE("Ping child: created handshake queue\n");
		sleep(1);
		
		/* read 1st handshake */
		length = MsgQueueRecv( handshakeMQ, inHandShake, MAXSIZE);
		if( 0 == length ) {
			HANDLE_ERR("MsgQueueRecv (handshake)");
		}
		
		pingData->m_nToSend += options.m_nMessages;
		++pingData->m_nPongs;

		/* unlock mutex */
		if( -1 == SyncMutexUnlock(pingMutex) ) {
			HANDLE_ERR("SyncMutexUnlock");
		}
		VERBOSE("Ping child: read 1st handshake & unlocked mutex\n");
		
		/* continue while parent still active */
		while( pingData->m_nSent < pingData->m_nToSend )
		{	
			length = MsgQueueRecv( handshakeMQ, inHandShake, MAXSIZE);
			if( 0 == length ) {
				HANDLE_ERR("MsgQueueRecv (handshake)");
			}
		
			if( strncmp(inHandShake, byeMsg, length) )
			{
				pingData->m_nToSend += options.m_nMessages;
				++pingData->m_nPongs;
				
				VERBOSE_INT("Ping child: read handshake #", pingData->m_nPongs, "\n");
				continue;
			}
			/* else */
			break;
			
		} /* end while */
		
		MsgQueueDestroy( handshakeMQ );
		VERBOSE("Ping child: destroyed handshake queue\n");
		ShmemDisconnect(pingShmem, pingShmid, 0);
		VERBOSE("Ping child: disconnected from shared mem\n");
		
		return 0;

	}	/*** END CHILD ***/
	
/*** PARENT - actual messages ***/
	else /*if(pid > 0)*/
	{
		int length;
		int sent;
		
		pingMutex = SyncAttach(pingSync, 0);
		
		/* create message queue */
		myMQ = MsgQueueCreate( options.m_filename, options.m_queueSize, PAGESIZE);
		if( !myMQ ) {
			HANDLE_ERR("MsgQueueCreate");
		}
		VERBOSE("Ping parent: created message queue\n");
		
		/* wait for 1st pong to arrive */
		VERBOSE("Ping parent: waiting for 1st pong\n");
		if( -1 == SyncMutexLock(pingMutex) ) {
			HANDLE_ERR("SyncMutexLock");
		}		
		VERBOSE("Ping parent: notified of 1st pong\n");
		
		srand(time(0));
		
		/****** SEND MESSAGES ******/
		
		while( pingData->m_nSent < pingData->m_nToSend )
		{
			length = rand()%MAXSIZE + 1;	/* random length */
			memcpy( outMsg, defMsg, length );
			
			sent = MsgQueueSend( myMQ, outMsg, length );
			if( 0 == sent ) {
				HANDLE_ERR("MsgQueueSend");
			}
			
			++pingData->m_nSent;
			
			outMsg[sent] = '\0';
			printf("Ping: sent msg # %d of %d: %s\n", pingData->m_nSent, pingData->m_nToSend, outMsg);
			
			sleep(options.m_sleep);
		}	/* end while */
		
		/* send bye-bye message */
		length = strlen(byeMsg);
		sent = MsgQueueSend( myMQ, byeMsg, length );
		if( 0 == sent ) {
			HANDLE_ERR("MsgQueueSend");
		}
		
		++pingData->m_nSent;
		printf("Ping: sent byebye msg: %s\n", byeMsg);
		
		/* destroy mutex & shared mem */
		SyncDestroy(pingSync);
		ShmemDisconnect(pingShmem, pingShmid, 1);
		VERBOSE("Ping parent: destroyed mutex & shared mem\n");
		
		/* destroy myMQ */
		MsgQueueDestroy( myMQ );
		VERBOSE("Ping parent: destroyed message queue\n");
		
	}	/*** END PARENT ***/
	
	/* wait for all processes ot finish */
	wait(NULL);
	
	return 0;
}
/*######################################################################*/






