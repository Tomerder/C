/*******************************************************************************
	Author:				Stav Ofer
	Creation date:		2013-09-16
	Date last modified:	2013-09-30
	Description:		Message Queue over Shared Memory in multi-process interlock
********************************************************************************/

#ifndef _XOPEN_SOURCE
#define _XOPEN_SOURCE 600
#endif

#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <assert.h>
#include <sys/types.h>
#include <sys/ipc.h>


#include "QueueNew.h"
#include "MPoolNew.h"
#include "Sync.h"
#include "SharedMem.h"

#include "MsgQueue.h"



/*######################################################################*/
/*				DEFINITIONS & FOREWARD DECLARATIONS						*/
/*######################################################################*/

#define NTOOLS			3

#define MIN_POOL_SIZE	32

#define OFFSET2ADDR(BASE,OFFSET)	(char*)(BASE) + (OFFSET)
#define HANDLE_ERR(X,R)				fprintf(stderr, "%s:%d Error: %s\n", __FILE__, __LINE__, X); return(R)

/* sync tool IDs */
enum Tools
{
	SEM_FULL,
	SEM_EMPTY,
	MUTEXTOOL
};


/* offset table - internal */
typedef struct OffsetTable
{
	size_t	m_sync;
	size_t	m_queue;
	size_t	m_pool;
	
} OffsetTable_t;


/*** Message Queue ***/
struct MQ
{
	Shmem_t		m_shmem;
	void*		m_address;
	Sync_t*		m_sync;
	Queue_t*	m_queue;
	MPool*		m_pool;
	int			m_createFlag;
};


/* create msgQ, create/connect to shared memory, return NULL for error */
static MQ_t*	MsgQMemCreate	(char *_msgQueueName, size_t _memSize, int _create);


/*######################################################################*/
/*								API FUNCTIONS							*/
/*######################################################################*/


/*----------------------------------------------------------------------*/
/*					CREATE, CONNECT, DESTROY							*/
/*----------------------------------------------------------------------*/

/* create shared memory, allocate in it requred structures, & create process/thread local metadata */
/* return NULL for errors */
MQ_t*	MsgQueueCreate	(char *_msgQueueName, size_t _msgMax, size_t _memSize)
{
	MQ_t *msgQ = NULL;
	OffsetTable_t* table = NULL;
	int tableSize, syncSize, queueSize, poolSize;
	
	assert( _msgQueueName && _msgMax );
	
	/* calculate sizes, check that _memSize is enough */
	tableSize = sizeof(OffsetTable_t);
	syncSize  = SyncGetSize(NTOOLS);
	queueSize = QueueGetSize(_msgMax);
	poolSize  = MIN_POOL_SIZE;
	
	assert( _memSize >= tableSize + syncSize + queueSize + poolSize );
	
	/* create messageQ & shared memory */
	msgQ = MsgQMemCreate(_msgQueueName, _memSize, 1);
	if( !msgQ ) {
		HANDLE_ERR("MsgQueueCreate", NULL);
	}
	
	/* create & populate offset table */
	table = (OffsetTable_t*)msgQ->m_address;
	table->m_sync  = tableSize;
	table->m_queue = table->m_sync + syncSize;
	table->m_pool  = table->m_queue + queueSize;
	
	/* create & init sync tools: 2 semaphores and 1 mutex */
	msgQ->m_sync = SyncCreate( OFFSET2ADDR(msgQ->m_address, table->m_sync), NTOOLS);
	if( !msgQ->m_sync ) {
		HANDLE_ERR("MsgQueueCreate", NULL);
	}
	SyncToolInit(msgQ->m_sync, SEM_FULL,  SEMAPHORE, _msgMax);
	SyncToolInit(msgQ->m_sync, SEM_EMPTY, SEMAPHORE, 0);
	SyncToolInit(msgQ->m_sync, MUTEXTOOL, MUTEX, 	 1);
	
	/* create queue of message offsets */
	msgQ->m_queue = QueueCreate( OFFSET2ADDR(msgQ->m_address, table->m_queue), _msgMax);
	if( !msgQ->m_queue ) {
		HANDLE_ERR("MsgQueueCreate", NULL);
	}
	
	/* create MPool in remaining memory */
	msgQ->m_pool = MPoolInit( OFFSET2ADDR(msgQ->m_address, table->m_pool),  _memSize - table->m_pool );
	if( !msgQ->m_pool ) {
		HANDLE_ERR("MsgQueueCreate", NULL);
	}
	
	/* correct pool offset */
	table->m_pool = (char*)msgQ->m_pool - (char*)msgQ->m_address;
	
	return msgQ;
}
/*----------------------------------------------------------------------*/

/* connect to shared memory & create process/thread local metadata */
/* return NULL for errors */
MQ_t*	MsgQueueConnect	(char *_msgQueueName)
{
	MQ_t *msgQ;
	OffsetTable_t* table = NULL;
	
	assert( _msgQueueName );
	
	/* create messageQ & connect to shared memory */
	msgQ = MsgQMemCreate(_msgQueueName, 1, 0);
	if( !msgQ ) {
		HANDLE_ERR("MsgQueueConnect", NULL);
	}
	
	/* get table & set msgQ pointers */
	table = (OffsetTable_t*)msgQ->m_address;
	
	msgQ->m_sync	= (Sync_t*) ( OFFSET2ADDR(msgQ->m_address, table->m_sync) );
	msgQ->m_queue	= (Queue_t*)( OFFSET2ADDR(msgQ->m_address, table->m_queue) );
	msgQ->m_pool	= (MPool*)  ( OFFSET2ADDR(msgQ->m_address, table->m_pool) );
	
	return msgQ;
}
/*----------------------------------------------------------------------*/

/* disconnect from shared memory & free _msgQue */
/* if shared memory was created in this session, it is set to be destroyed
	upon disconnection of last process */ 
void	MsgQueueDestroy	(MQ_t *_msgQue)
{
	assert( _msgQue );
	
	ShmemDisconnect( _msgQue->m_shmem );
	
	if( _msgQue->m_createFlag ) {
		ShmemDestroy( _msgQue->m_shmem );
	}
	
	free( _msgQue );
}
/*----------------------------------------------------------------------*/


/*----------------------------------------------------------------------*/
/*				Message Manipulation: Send, Receive						*/
/*----------------------------------------------------------------------*/

/* return number of bytes actually written, 0 if message queue (mpool) full or other error */
/* return value DOES NOT include 1 int of message length */
int		MsgQueueSend	(MQ_t *_msgQue, void* _buffer, size_t _length)
{
	SyncTool_t* semFull;
	SyncTool_t* semEmpty;
	SyncTool_t* mutex;
	void* destination;
	int offset;
	int writing = _length + sizeof(int);
	
	assert( _msgQue && _buffer && _length);
	
	/* connect to sync tools */
	semFull		= SyncAttach(_msgQue->m_sync, SEM_FULL);
	semEmpty	= SyncAttach(_msgQue->m_sync, SEM_EMPTY);
	mutex		= SyncAttach(_msgQue->m_sync, MUTEXTOOL);
	
	/* wait if full */
	if( -1 == SyncSemDown(semFull) ) {
		HANDLE_ERR("MsgQueueSend", 0);
	}
	
/*********** START mutex-protected section ***********/
	SyncMutexLock(mutex);
	
	/* allocate memory */
	destination = MPoolAlloc(_msgQue->m_pool, writing);
	if( !destination )
	{
		SyncMutexUnlock(mutex);
		SyncSemUp(semFull);
		HANDLE_ERR("MsgQueueSend", 0);
	}
	
	SyncMutexUnlock(mutex);
/*********** END mutex-protected section ***********/
	
	/* write message */
	*(int*)destination = _length;
	memcpy( OFFSET2ADDR(destination, sizeof(int)), _buffer, _length);
	
	/* calculate offset */
	offset = (unsigned int)destination - (unsigned int)_msgQue->m_pool;
	
/********** START mutex-protected section **********/
	SyncMutexLock(mutex);
	
	/* insert offset to queue */
	QueueInsert(_msgQue->m_queue, offset);
	
	SyncMutexUnlock(mutex);
/********** END mutex-protected section **********/
	
	/* update empty semaphore */
	if( -1 == SyncSemUp(semEmpty) ) {
		HANDLE_ERR("MsgQueueSend", 0);
	}
	
/*	return writing;*/
	return _length;
}
/*----------------------------------------------------------------------*/

/* return number of bytes actually read, 0 if message queue unavailable */ 
int		MsgQueueRecv	(MQ_t *_msgQue, void* _buffer, size_t _size)
{
	SyncTool_t* semFull;
	SyncTool_t* semEmpty;
	SyncTool_t* mutex;
	void* source;
	int offset;
	int reading;
	
	assert( _msgQue && _buffer && _size);
	
	/* connect to sync tools */
	semFull		= SyncAttach(_msgQue->m_sync, SEM_FULL);
	semEmpty	= SyncAttach(_msgQue->m_sync, SEM_EMPTY);
	mutex		= SyncAttach(_msgQue->m_sync, MUTEXTOOL);
	
	/* wait if empty */
	if( -1 == SyncSemDown(semEmpty) ) {
		HANDLE_ERR("MsgQueueSend", 0);
	}
	
/********** START mutex-protected section **********/
	SyncMutexLock(mutex);
	
	/* get offset from queue */
	if( -1 == QueueRemove(_msgQue->m_queue, &offset) )
	{		
		SyncMutexUnlock(mutex);
		SyncSemUp(semEmpty);
		HANDLE_ERR("MsgQueueSend", 0);
	}
	
	SyncMutexUnlock(mutex);
/********** END mutex-protected section **********/
	
	/* address */
	source = OFFSET2ADDR(_msgQue->m_pool, offset);
	
	/* get message length, then message */
	reading = (*(int*)source > _size) ? _size : *(int*)source;
	memcpy(_buffer, OFFSET2ADDR( source, sizeof(int) ), reading);
	
/********** START mutex-protected section **********/
	SyncMutexLock(mutex);
	
	/* free memory */
	MPoolFree(_msgQue->m_pool, source);
	
	SyncMutexUnlock(mutex);
/********** END mutex-protected section **********/

	/* update full semaphore */
	if( -1 == SyncSemUp(semFull) ) {
		HANDLE_ERR("MsgQueueSend", 0);
	}
	
	return reading;
}
/*----------------------------------------------------------------------*/


/*----------------------------------------------------------------------*/
/*								IsEmpty									*/
/*----------------------------------------------------------------------*/
int		IsMsgQueueEmpty (MQ_t *_msgQue)
{
	return IsQueueEmpty(_msgQue->m_queue);
}
/*----------------------------------------------------------------------*/


/*----------------------------------------------------------------------*/
/* Utility Functions for debugging and unit testing */
/*----------------------------------------------------------------------*/
void	MsgQueuePrint	(MQ_t* _msgQue)
{
	/**/
}
/*----------------------------------------------------------------------*/


/*######################################################################*/
/*							INTERNAL FUNCTIONS							*/
/*######################################################################*/

/*----------------------------------------------------------------------*/
/* create msgQ, create/connect to shared memory, return NULL for error */
MQ_t*	MsgQMemCreate(char *_msgQueueName, size_t _memSize, int _create)
{
	MQ_t* msgQ = NULL;
	
	/* allocate msgQ & initialize to all-0 */
	msgQ = (MQ_t*)malloc(sizeof(MQ_t));
	if( !msgQ ) {
		return NULL;
	}
	memset(msgQ, 0, sizeof(MQ_t));
	
	/* set create flag */
	msgQ->m_createFlag = _create;
	
	/* connect to shared mem */
	msgQ->m_shmem = ShmemGet(_msgQueueName, _memSize, _create);
	if( !msgQ->m_shmem )
	{
		MsgQueueDestroy(msgQ);
		return NULL;
	}
	
	/* get shmem address */
	msgQ->m_address = ShmemConnect(msgQ->m_shmem);
	if( !msgQ->m_address )
	{
		MsgQueueDestroy(msgQ);
		return NULL;
	}
	
	return msgQ;
}
/*----------------------------------------------------------------------*/



