/*****************************************************************************************************************
*    AUTHOR: Tomer Dery                                                                                 
*    DATE: 12.02.14                                                                                              
*    LAST MODIFIED: 12.02.14                                                                                  
*    DESCRIPTION: Thread - consumer consumer 
*****************************************************************************************************************/
#define _XOPEN_SOURCE 500
/*-----------------------------------------------------------------*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>
#include <time.h>
#include <assert.h>

/*-----------------------------------------------------------------*/

#include "cons.h"

/*-----------------------------------------------------------------*/

enum{FALSE , TRUE};

enum{OK_E, ALOC_ERR , SEM_INIT_ERR , THREAD_JOIN_ERR};

#define WORK_TIME 100000

#define CHKERR(ERR) if(ERR != OK_E) { printf("ERROR : %d\n",ERR); return ERR; }

/*-----------------------------------------------------------------*/

struct Consume_t{
	int m_maxQueueSize;	
	Queue* m_queue;
	pthread_mutex_t* m_mutex;
	pthread_cond_t* m_cond;
};

/*-----------------------------------------------------------------*/

Consume_t* ConsumeInit(Queue* _queue, pthread_mutex_t* _mutex, pthread_cond_t* _cond, size_t _maxQueueSize)
{
	Consume_t* cons = NULL;

	assert(_queue);
	assert(_mutex);		
	assert(_cond);
	assert(_maxQueueSize);		

	cons = malloc(sizeof(Consume_t));               
	if(cons == NULL){
		return NULL;
	} 	
	
	cons->m_maxQueueSize = _maxQueueSize;
	cons->m_queue = _queue;
	cons->m_mutex = _mutex;		
	cons->m_cond = _cond;
		
	return cons;
}

/*-----------------------------------------------------------------*/

void ConsumeDestroy(Consume_t* _consume)
{
	free(_consume);
}

/*-----------------------------------------------------------------*/

void* Consume(Consume_t* _consume)
{
	int err;
	void* removedItem;
    
    /*--------------------------------------*/
	/*lock*/
	pthread_mutex_lock(_consume->m_mutex);
		
	while ( IsQueueEmpty(_consume->m_queue) ) 
	{
		/*wait for consumer*/
		err = pthread_cond_wait(_consume->m_cond, _consume->m_mutex);
	}	
	
	/*remove item from queue*/
	QueueRemove(_consume->m_queue, &removedItem);
	
	/*unlock*/
	pthread_mutex_unlock(_consume->m_mutex);
    /*--------------------------------------*/
    
   	/*signal to producer*/
    err = pthread_cond_signal( _consume->m_cond); 
   
    
	return removedItem;
}

/*-----------------------------------------------------------------*/
